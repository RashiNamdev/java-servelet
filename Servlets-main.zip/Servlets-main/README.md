Create 3 servelet by using generic  servelet, http servelet , servelet class. which can manage session and print the session value.
